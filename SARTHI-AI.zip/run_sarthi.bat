@echo off
title SARTHI - AK AI Assistant
cd /d "%~dp0"

echo ===================================================
echo           SARTHI - AK AI Assistant
echo ===================================================
echo.
echo Launching SARTHI...

py -3.14 main.py 2>nul
if %errorlevel% neq 0 (
    py -3.13 main.py 2>nul
    if %errorlevel% neq 0 (
        python main.py
    )
)

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Failed to launch SARTHI.
    echo Please make sure dependencies are installed with: python setup.py
    echo.
    pause
)
