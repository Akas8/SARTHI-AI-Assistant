import sys
import py_compile
from pathlib import Path

sarthi_dir = Path(__file__).resolve().parent
print(f"Testing SARTHI codebase at: {sarthi_dir}")

files_to_compile = [
    sarthi_dir / "setup.py",
    sarthi_dir / "main.py",
    sarthi_dir / "ui.py",
]

# Add all core and action files
for p in (sarthi_dir / "core").glob("*.py"):
    files_to_compile.append(p)
for p in (sarthi_dir / "actions").glob("*.py"):
    files_to_compile.append(p)
for p in (sarthi_dir / "memory").glob("*.py"):
    files_to_compile.append(p)

success_count = 0
for f in files_to_compile:
    try:
        py_compile.compile(str(f), doraise=True)
        success_count += 1
    except Exception as e:
        print(f"FAILED: {f.name} -> {e}")
        sys.exit(1)

print(f"\nALL {success_count} PYTHON FILES COMPILED CLEANLY WITH ZERO SYNTAX ERRORS!")
